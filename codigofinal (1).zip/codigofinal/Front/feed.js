const button = document.getElementById('handleSubmit');

button.onclick = async function (e) {
    e.preventDefault();
    //cancela o comportamento padrão de um formulario, tem que colocar o "e" no parametro

    let inputText = document.getElementById('inputText').value;
    
    let data = { inputText }

    // POST
    const response = await fetch('http://localhost:3008/api/store/feed', {
        method: "POST",
        headers: { "Content-type": "application/json;charset=UTF-8" },
        body: JSON.stringify(data)
    });

    let content = await response.json();
    console.log(content);
    
    if (content.sucess) {
        alert ("Sucesso com o POST!!");
        // window.location.reload();
        //recarrega a página

        // CRIAR O CARD

    } else {
        console.error()
        alert("Não deu o POST!!");
    };
};